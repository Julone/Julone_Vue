-- MySQL dump 10.13  Distrib 5.6.41, for Linux (x86_64)
--
-- Host: localhost    Database: dqliemdt_julone
-- ------------------------------------------------------
-- Server version	5.6.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `navcom`
--

DROP TABLE IF EXISTS `navcom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navcom` (
  `navId` int(255) NOT NULL AUTO_INCREMENT,
  `navName` varchar(255) NOT NULL,
  `navText` longtext NOT NULL,
  `navImg` mediumtext NOT NULL,
  `navTime` varchar(255) NOT NULL,
  `navTop` varchar(50) DEFAULT NULL,
  `deleted` varchar(50) NOT NULL DEFAULT '0',
  `postId` varchar(2555) NOT NULL,
  PRIMARY KEY (`navId`)
) ENGINE=MyISAM AUTO_INCREMENT=347 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navcom`
--

LOCK TABLES `navcom` WRITE;
/*!40000 ALTER TABLE `navcom` DISABLE KEYS */;
INSERT INTO `navcom` (`navId`, `navName`, `navText`, `navImg`, `navTime`, `navTop`, `deleted`, `postId`) VALUES (1,'Julone','做了好久，坐了好久','','2018-07-22 19:56:24',NULL,'0','julone@qq.com'),(18,'Julone','我就很纳闷，为啥我看视频看一会就像睡觉。','','2018-07-26 18:02:45',NULL,'0','julone@qq.com'),(4,'Julone','后来才发现<br>深夜，才会真正属于自己<br>世界都睡了&nbsp;爹妈也睡了<br>同学都睡了&nbsp;老师也睡了','','2018-07-23 15:36:09',NULL,'0','julone@qq.com'),(10,'Julone','改变世界的锤子TNT终于被你们笑话死了<br>','','2018-07-24 15:26:23',NULL,'0','julone@qq.com'),(105,'Julone','下午真的是热«han_56»«han_56»«han_56»','upload/20180801_185610_0.jpg?upload/20180801_185613_1.jpg','2018-08-01 18:56:14',NULL,'0','julone@qq.com'),(107,'Julone','«sx_56»','upload/20180804_021052_0.jpg','2018-08-04 02:10:52',NULL,'0','julone@qq.com'),(160,'Julone','一个感人的小故事«bz_56»','upload/20180826_022505_0.png.webp','2018-08-26 02:25:06',NULL,'0','julone@qq.com'),(161,'Julone','<p style=\"max-width: 100%; clear: both; min-height: 1em; color: rgb(51, 51, 51); font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; font-size: 17px; letter-spacing: 0.544px; text-align: center; line-height: 1.75em; word-wrap: break-word !important;\"><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\">满院的蔷薇开得正好，红红白白</span><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\"></span></p><p style=\"max-width: 100%; clear: both; min-height: 1em; color: rgb(51, 51, 51); font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; font-size: 17px; letter-spacing: 0.544px; text-align: center; line-height: 1.75em; word-wrap: break-word !important;\"><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\">颤颤巍巍，一蓬一蓬的</span><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\"></span></p><p style=\"max-width: 100%; clear: both; min-height: 1em; color: rgb(51, 51, 51); font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; font-size: 17px; letter-spacing: 0.544px; text-align: center; line-height: 1.75em; word-wrap: break-word !important;\"><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\">热闹得不分贵贱好丑</span><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\"></span></p><p style=\"max-width: 100%; clear: both; min-height: 1em; color: rgb(51, 51, 51); font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; font-size: 17px; letter-spacing: 0.544px; text-align: center; line-height: 1.75em; word-wrap: break-word !important;\"><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\">和蔷薇一起长大的孩子</span><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\"></span></p><p style=\"max-width: 100%; clear: both; min-height: 1em; color: rgb(51, 51, 51); font-family: -apple-system-font, BlinkMacSystemFont, &quot;Helvetica Neue&quot;, &quot;PingFang SC&quot;, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft YaHei&quot;, Arial, sans-serif; font-size: 17px; letter-spacing: 0.544px; text-align: center; line-height: 1.75em; word-wrap: break-word !important;\"><span style=\"max-width: 100%; font-size: 14px; letter-spacing: 1px; color: rgb(136, 136, 136); word-wrap: break-word !important;\">却从此有了高低间的距离</span></p>','','2018-08-26 13:07:09',NULL,'0','julone@qq.com'),(127,'Julone','每日必备: 带娃 + 代码«ka_56»«ka_56»','upload/20180814_210056_0.png?upload/20180814_210056_1.jpg?upload/20180814_210057_2.jpg','2018-08-14 21:00:57',NULL,'0','julone@qq.com'),(116,'Julone','有一个传说，<div>说 欧若拉 是一头巨鲸掀起了波涛，</div><div>飞到了 天上。</div>','upload/20180811_171238_0.jpg','2018-08-11 17:12:38',NULL,'0','julone@qq.com'),(128,'Julone','','upload/20180816_125205_0.jpg','2018-08-16 12:52:05',NULL,'0','julone@qq.com'),(131,'Julone','','upload/20180816_235052_0.jpg.webp?upload/20180816_235052_1.jpg.webp?upload/20180816_235053_2.jpg.webp?upload/20180816_235053_3.jpg.webp','2018-08-16 23:50:53',NULL,'0','julone@qq.com'),(147,'Julone','','upload/20180824_173449_0.jpeg.webp','2018-08-24 17:34:51',NULL,'0','julone@qq.com'),(146,'Julone','有点意思，有点创意«cy_56»','upload/20180822_224823_0.jpg.webp','2018-08-22 22:48:24',NULL,'0','julone@qq.com'),(144,'julone','','upload/20180819_231144_0.jpg.webp?upload/20180819_231149_1.jpg.webp?upload/20180819_231153_2.jpg.webp?upload/20180819_231157_3.jpg.webp','2018-08-19 23:12:07',NULL,'0','julone@qq.com'),(163,'Julone','又大了一岁，祝自己21岁生日快乐«cy_56»«cy_56»','upload/20180826_171642_0.jpg.webp','2018-08-26 17:16:43',NULL,'0','julone@qq.com'),(166,'Julone','那么就把今天这个教训，记住。«zm_56»','upload/20180828_001831_0.png.webp','2018-08-28 00:18:32',NULL,'0','julone@qq.com'),(172,'Julone','故事的开头总是这样,适逢其会,猝不及防。故事的结局总是这样,花开两朵,天各一方。«qiang_56»','','2018-09-06 17:42:04',NULL,'0','julone@qq.com'),(168,'Julone','','upload/20180901_134110_0.jpg.webp?upload/20180901_134110_1.jpg.webp?upload/20180901_134111_2.jpg.webp','2018-09-01 13:41:11',NULL,'0','julone@qq.com'),(170,'Julone','Java洗衣液«shuai_56»«shuai_56»','upload/20180904_002930_0.png.webp','2018-09-04 00:29:30',NULL,'0','julone@qq.com'),(173,'Julone','一到中午就想睡觉','','2018-09-07 12:30:04',NULL,'0','julone@qq.com'),(175,'Julone','多少次 我回回头 看看走过的路<div>衷心祝福你 善良的姑娘</div><div>多少次 我回回头 看看走过的路</div><div>你 站在小河旁</div>','upload/20180909_023733_0.jpg.webp','2018-09-09 02:37:34',NULL,'0','julone@qq.com'),(186,'Julone','哇看了下尤大大的代码，水平真的是高，逻辑写的好出色«qiang_56»','upload/20180923_180032_0.png.webp','2018-09-23 18:00:32',NULL,'0','julone@qq.com'),(182,'Julone','真是令人Boring«zj_56»«zj_56»','upload/20180913_110742_0.jpg.webp','2018-09-13 11:07:46',NULL,'0','julone@qq.com'),(184,'Julone','','upload/20180919_103608_0.gif.webp','2018-09-19 10:36:12',NULL,'0','julone@qq.com'),(196,'Julone','','upload/20180924_205736_0.png.webp','2018-09-24 20:57:37',NULL,'0','julone@qq.com'),(207,'Julone','«shuai_56»这么逗吗','upload/20180930_095305_0.gif.webp','2018-09-30 09:53:09',NULL,'0','julone@qq.com'),(202,'Julone','http://m.ui.cn/details/401668','upload/20180929_091612_0.gif.webp?upload/20180929_091612_1.gif.webp?upload/20180929_091613_2.gif.webp?upload/20180929_091613_3.gif.webp?upload/20180929_091613_4.gif.webp?upload/20180929_091613_5.gif.webp','2018-09-29 09:16:13',NULL,'0','julone@qq.com'),(297,'Julone','','upload/20181012_093732_0.jpg.webp','2018-10-12 09:37:33',NULL,'0','julone@qq.com'),(302,'Julone','console.log(...desktop)<img src=\"https://julone.cf/nav/img/face/han_56.gif\"><img src=\"https://julone.cf/nav/img/face/han_56.gif\">','upload/20181015_021629_0.jpg.webp','2018-10-15 02:16:30',NULL,'0','julone@qq.com'),(324,'Julone','','upload/20181101_183446_0.jpg.webp','2018-11-01 18:34:46',NULL,'0','julone@qq.com'),(306,'julone','«gz_56»','','2018-10-17 09:50:07',NULL,'0','julone@qq.com'),(311,'julone','👶','upload/20181020_154447_0.jpg.webp','2018-10-20 15:44:48',NULL,'0','julone@qq.com'),(317,'柯少爷','嗨«shuai_56»«shuai_56»«shuai_56»','','2018-10-30 13:40:30',NULL,'0','15359639480'),(322,'Julone','The brown fox jumps the lazy dog','upload/20181031_215229_0.gif.webp?upload/20181031_215229_1.gif.webp','2018-10-31 21:52:29',NULL,'0','julone@qq.com'),(314,'Julone','<span style=\"color: rgb(34, 34, 34); font-family: Consolas, &quot;Lucida Console&quot;, &quot;Courier New&quot;, monospace; font-size: 12px; letter-spacing: normal; white-space: pre-wrap;\">荣耀存于心，而非留于形</span><div><span style=\"color: rgb(34, 34, 34); font-family: Consolas, &quot;Lucida Console&quot;, &quot;Courier New&quot;, monospace; font-size: 12px; letter-spacing: normal; white-space: pre-wrap;\">长路漫漫，唯剑做伴</span></div><div><span style=\"color: rgb(34, 34, 34); font-family: Consolas, &quot;Lucida Console&quot;, &quot;Courier New&quot;, monospace; font-size: 12px; letter-spacing: normal; white-space: pre-wrap;\">且随疾风前行，身后一许流星</span></div><div><span style=\"color: rgb(34, 34, 34); font-family: Consolas, &quot;Lucida Console&quot;, &quot;Courier New&quot;, monospace; font-size: 12px; letter-spacing: normal; white-space: pre-wrap;\">吾虽浪迹天涯， 却未迷失本心</span><br></div>','','2018-10-24 12:31:20',NULL,'0','julone@qq.com'),(315,'Julone','先走的那个人总是可以轻而易举的说走就走，先动感情的那个人，只能留在原地，故作镇定。','','2018-10-27 23:00:48',NULL,'0','julone@qq.com'),(333,'Kk','哈哈','','2018-11-08 08:50:04',NULL,'0','1925841400'),(340,'Julone','发生的发生','','2018-11-10 21:06:44',NULL,'2018-11-11 13:58:57','julone@qq.com'),(342,'Julone','5353','','2018-11-10 21:09:05',NULL,'2018-11-11 13:58:54','julone@qq.com'),(346,'Julone','','upload/20181124_091539_0.jpeg.webp','2018-11-24 09:15:39',NULL,'0','julone@qq.com'),(343,'Julone','','upload/20181110_232121_0.jpg.webp?upload/20181110_232121_1.jpg.webp?upload/20181110_232121_2.jpg.webp?upload/20181110_232122_3.jpg.webp?upload/20181110_232122_4.jpg.webp?upload/20181110_232122_5.jpg.webp','2018-11-10 23:21:21','2018-11-14 10:12:55','0','julone@qq.com'),(344,'Julone','«sa_56»«sa_56»«sa_56»«sa_56»','upload/20181112_130114_0.jpg.webp','2018-11-12 13:01:14',NULL,'2018-11-12 13:01:19','julone@qq.com'),(345,'柯少爷-','第500万个访客','','2018-11-14 09:28:56',NULL,'0','15359639480');
/*!40000 ALTER TABLE `navcom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navlike`
--

DROP TABLE IF EXISTS `navlike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navlike` (
  `guid` int(11) NOT NULL AUTO_INCREMENT,
  `navId` varchar(20055) DEFAULT NULL,
  `postId` mediumtext,
  `liked` varchar(10) DEFAULT '0',
  `likeTime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`guid`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navlike`
--

LOCK TABLES `navlike` WRITE;
/*!40000 ALTER TABLE `navlike` DISABLE KEYS */;
INSERT INTO `navlike` (`guid`, `navId`, `postId`, `liked`, `likeTime`) VALUES (93,'343','julone@qq.com','1','2018-11-11 13:58:48'),(74,'322','1925841400','1','2018-11-05 09:56:02'),(87,'322','julone@qq.com','1','2018-11-10 23:21:39'),(86,'306','julone@qq.com','1','2018-11-09 01:21:54'),(94,'317','15359639480','1','2018-11-12 15:05:43'),(95,'343','15359639480','1','2018-11-12 15:06:24'),(96,'333','15359639480','1','2018-11-12 15:06:28'),(97,'315','15359639480','1','2018-11-12 15:06:34'),(99,'314','15359639480','1','2018-11-12 15:06:39'),(100,'302','15359639480','1','2018-11-12 15:06:43');
/*!40000 ALTER TABLE `navlike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replycom`
--

DROP TABLE IF EXISTS `replycom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `replycom` (
  `guid` int(11) NOT NULL AUTO_INCREMENT,
  `navId` varchar(255) DEFAULT NULL,
  `replyType` varchar(255) NOT NULL DEFAULT '0',
  `to_userId` varchar(255) DEFAULT NULL,
  `from_userId` varchar(255) DEFAULT NULL,
  `huifu` mediumtext,
  `posttime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`guid`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replycom`
--

LOCK TABLES `replycom` WRITE;
/*!40000 ALTER TABLE `replycom` DISABLE KEYS */;
INSERT INTO `replycom` (`guid`, `navId`, `replyType`, `to_userId`, `from_userId`, `huifu`, `posttime`) VALUES (53,'322','0','julone@qq.com','julone@qq.com','发现数据库建表真的是难难难!','2018-11-05 15:44:00'),(56,'333','0','1925841400','julone@qq.com','为你疯狂打CALL😚','2018-11-09 16:09:11');
/*!40000 ALTER TABLE `replycom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `replylike`
--

DROP TABLE IF EXISTS `replylike`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `replylike` (
  `guid` int(11) NOT NULL AUTO_INCREMENT,
  `replyId` varchar(255) DEFAULT NULL,
  `postId` varchar(255) DEFAULT NULL,
  `liked` varchar(255) DEFAULT NULL,
  `likeTime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `replylike`
--

LOCK TABLES `replylike` WRITE;
/*!40000 ALTER TABLE `replylike` DISABLE KEYS */;
/*!40000 ALTER TABLE `replylike` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stu`
--

DROP TABLE IF EXISTS `stu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stu` (
  `username` varchar(50) NOT NULL,
  `realname` varchar(50) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stu`
--

LOCK TABLES `stu` WRITE;
/*!40000 ALTER TABLE `stu` DISABLE KEYS */;
INSERT INTO `stu` (`username`, `realname`) VALUES ('163110108','胡嘉艳'),('163110109','黄忠梁'),('163110110','缪靖'),('163110111','叶云松'),('163110112','余志成'),('163110113','李柯伟'),('163110114','陈郁材'),('163110115','周可扬'),('163110116','林俊宇'),('163110117','郑斯佳'),('163110118','胡毅帆'),('163110119','黄钦敏'),('163110120','臧元'),('163110121','叶巧丽'),('163110122','吴凯彬'),('163110123','李祖龙'),('163110124','陈俊凯'),('163110125','林万佳'),('163110126','林星成'),('163110127','郑德锦'),('163110128','钟震宇'),('163110129','黄宽通'),('163110130','潘政'),('163110131','叶芳'),('163110132','吴婉清'),('163110133','杨萍'),('163110134','陈娜'),('163110135','林兰因'),('163110136','林晟'),('163110137','金晓蔚'),('163110138','唐勇'),('163110139','黄燕艺'),('163110140','薛有清'),('163110141','叶晓琼'),('163110142','吴博浩'),('163110143','汪佳'),('163110144','陈彦翀'),('163110145','林巧良'),('163110146','林海'),('163110147','侯文沁'),('163110148','唐彩婷'),('163110149','黄燕槟'),('163110150','薛海英'),('163110151','刘武臣'),('163110152','吴琰义'),('163110154','陈津'),('163110155','林立伟'),('163110156','林婕'),('163110157','俞津颖'),('163110158','徐菲'),('163110159','温之航'),('163110160','薛鑫怡'),('153110074','吴梅娟');
/*!40000 ALTER TABLE `stu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userinfo`
--

DROP TABLE IF EXISTS `userinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userinfo` (
  `guid` int(11) NOT NULL AUTO_INCREMENT,
  `userId` varchar(50) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `userPass` varchar(50) NOT NULL,
  `userIcon` varchar(1000) NOT NULL,
  `isAdmin` varchar(10) NOT NULL DEFAULT 'false',
  `userSex` varchar(10) NOT NULL,
  `userBorn` varchar(100) NOT NULL,
  `userTime` varchar(50) NOT NULL,
  PRIMARY KEY (`guid`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userinfo`
--

LOCK TABLES `userinfo` WRITE;
/*!40000 ALTER TABLE `userinfo` DISABLE KEYS */;
INSERT INTO `userinfo` (`guid`, `userId`, `userName`, `userPass`, `userIcon`, `isAdmin`, `userSex`, `userBorn`, `userTime`) VALUES (104,'julone@qq.com','Julone','julone520','headIcon/sm_20181104_210704_518.jpg','true','男生','1997-08-25T16:00:00.000Z','2018-10-29 20:23:32'),(105,'15359639480','柯少爷-','keshaoye','headIcon/sm_20181114_092809_821.jpeg','true','女生','2018-10-30T16:00:00.000Z','2018-10-29 20:26:24'),(106,'androidstudio','啦啦','123456','','false','','','2018-10-30 11:26:56'),(107,'1925841400','炎亚纶','Hh19980605','headIcon/sm_20181108_085039_202.png','false','男生','1998-05-31T16:00:00.000Z','2018-10-30 15:15:42'),(109,'julone2@qq.com','普通用户','julone520','','false','','','2018-11-05 14:04:27'),(110,'12345','Rty','12345','','false','','','2018-11-20 22:07:59');
/*!40000 ALTER TABLE `userinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`username`, `password`, `time`) VALUES ('163110144','35030219980926081x','2018-10-06 13:29:49'),('163110123','julone520','2018-11-12 14:13:56'),('163110155','200514','2018-08-25 21:46:36'),('163110138','160531','2018-10-09 17:10:56'),('163110126','21321X','2018-07-24 18:29:00'),('163110118','130532','2018-07-20 07:36:13'),('163110154','092737','2018-07-11 23:58:51'),('163110122','261796','2018-07-11 13:54:23'),('163110120','220106199808301013','2018-10-07 16:44:03'),('163110145','050512','2018-07-11 10:10:15'),('163110130','18053X','2018-07-11 15:12:06'),('163110148','066927','2018-07-15 11:25:00'),('163110151','123934','2018-08-27 18:25:10'),('163110146','111992','2018-07-11 21:39:00'),('163110152','090019','2018-07-11 21:39:24'),('163110121','187120','2018-07-15 11:24:36'),('163110159','140171','2018-07-18 09:32:31'),('163110116','043218','2018-08-30 13:18:41'),('183371456','julone520','2018-09-11 12:57:02'),('163110124','350321199706043619','2018-10-06 13:32:39'),('163110132','151880','2018-11-07 10:23:59');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dqliemdt_julone'
--

--
-- Dumping routines for database 'dqliemdt_julone'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-23 18:11:49
